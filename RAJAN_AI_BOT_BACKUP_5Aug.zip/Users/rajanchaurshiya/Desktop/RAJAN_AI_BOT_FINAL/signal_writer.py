# Signal saving system
