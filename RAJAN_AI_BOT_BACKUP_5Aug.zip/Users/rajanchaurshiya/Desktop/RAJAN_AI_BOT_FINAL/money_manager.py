import json
import os

BALANCE_FILE = 'balance.json'

# Load or initialize balance data
def load_balance():
    if not os.path.exists(BALANCE_FILE):
        return {
            "total_profit": 0,
            "total_loss": 0,
            "daily_loss_limit": 100,
            "trade_count": 0,
            "max_trades_per_day": 20
        }
    with open(BALANCE_FILE, 'r') as f:
        return json.load(f)

# Save balance data
def save_balance(data):
    with open(BALANCE_FILE, 'w') as f:
        json.dump(data, f, indent=2)

# Update balance after a trade result
def update_money(result, amount):
    balance = load_balance()
    
    if result == 'win':
        balance["total_profit"] += amount
    elif result == 'loss':
        balance["total_loss"] += amount
    
    balance["trade_count"] += 1
    save_balance(balance)

# Check risk limits
def check_limits():
    balance = load_balance()
    if balance["total_loss"] >= balance["daily_loss_limit"]:
        print("🛑 Trading stopped due to daily loss limit.")
        return False
    if balance["trade_count"] >= balance["max_trades_per_day"]:
        print("🛑 Trading stopped due to trade count limit.")
        return False
    return True

# Reset balance data (can be called manually if needed)
def reset_balance():
    data = {
        "total_profit": 0,
        "total_loss": 0,
        "daily_loss_limit": 100,
        "trade_count": 0,
        "max_trades_per_day": 20
    }
    save_balance(data)

