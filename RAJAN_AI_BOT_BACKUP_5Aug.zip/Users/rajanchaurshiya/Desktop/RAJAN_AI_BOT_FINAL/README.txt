Run using: python3 smart_tv_signal.py
