# Return comparator logic
