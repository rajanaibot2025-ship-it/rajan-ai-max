import time
from tvdata import get_candles
from place_trade import place_trade
from money_manager import update_money, check_limits
from ai_candle_brain import analyze_candle

def get_latest_candle():
    data = get_candles()

    # ✅ IndexError fix: check if data is valid
    if not data or len(data) == 0:
        print("❌ Candle data not received. Skipping...")
        return None

    last = data[-1]
    candle = {
        "time": last[1],
        "open": last[2],
        "high": last[3],
        "low": last[4],
        "close": last[5],
        "volume": last[6]
    }
    return candle

def generate_signal(candle):
    # ✅ AI Brain Analysis
    analysis = analyze_candle(candle)
    print(f"\n🧠 AI Candle Brain Output: {analysis['reason']} | Confidence: {analysis['confidence']}%")

    signal = None
    if analysis["signal"] == "buy":
        signal = "CALL"
    elif analysis["signal"] == "sell":
        signal = "PUT"

    return signal, analysis

def main():
    print("📡 SMART SIGNAL SYSTEM ACTIVE...")
    while True:
        if check_limits():
            print("🛑 Trading stopped due to risk limits.")
            break

        candle = get_latest_candle()
        if candle:
            signal, analysis = generate_signal(candle)

            if signal:
                print(f"📊 Signal: {signal} | Reason: {analysis['reason']}")
                result = place_trade(signal)
                update_money(result)
            else:
                print("⚠️ No clear signal this candle.")

        time.sleep(60)

if __name__ == "__main__":
    main()

